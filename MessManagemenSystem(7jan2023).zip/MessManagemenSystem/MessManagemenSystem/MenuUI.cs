﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace MessManagemenSystem
{
    public partial class MenuUI : UserControl
    {
        public MenuUI()
        {
            InitializeComponent();
        }

        //save Menu Record
        private void btnMSave_Click(object sender, EventArgs e)
        {
            string day = txtDay.Text;
            string checkDayExistQuery = "if exists ( Select Day From Menu Where  Day='" + day + "' ) select Day From Menu  else select '0';";
            string returnValue = DatabaseClass.retrieveSingleData(checkDayExistQuery);

            string breakFast = txtMBreakFast.Text;
            string lunch = txtMLunch.Text;
            string dinner = txtMDinner.Text;
            if (day == "" || breakFast == "" || lunch == "" || dinner == "" )
            {
                MessageBox.Show("Please Enter All the Data Fields!");
            }
            else
            {
                if (returnValue != "0")
                {
                    MessageBox.Show("Day Exist!");
                }
                else
                {
                    DatabaseClass.AddMenu(new MenuClass(day,breakFast,lunch,dinner));
                    MessageBox.Show("Menu Saved!");
                }
            }
        }

        // Delete Menu Record
        private void btnmDelete_Click(object sender, EventArgs e)
        {
            string day = txtDay.Text;
            string checkDayExistQuery = "if exists ( Select Day From Menu Where  Day='" + day + "' ) select Day From Menu  else select '0';";
            string returnValue = DatabaseClass.retrieveSingleData(checkDayExistQuery);

            if (returnValue == "0")
            {
                MessageBox.Show("Day Does Not Exist!");
            }
            else
            {
                string query = "Delete From Menu Where day='" + day+ "';";
                DatabaseClass.SqlQuery(query);
                MessageBox.Show("Record of day '"+day+"' Deleted!");
            }
        }

        // Update Menu Record
        private void btnMUpdate_Click(object sender, EventArgs e)
        {
            string day = txtDay.Text;
            string checkDayExistQuery = "if exists ( Select Day From Menu Where  Day='" + day + "' ) select Day From Menu  else select '0';";
            string returnValue = DatabaseClass.retrieveSingleData(checkDayExistQuery);

            if (returnValue == "0")
            {
                MessageBox.Show("Day Does Not Exist!");
            }
            else
            {
                string breakFast = txtMBreakFast.Text;
                string lunch = txtMLunch.Text;
                string dinner = txtMDinner.Text;
                string query = "Update Menu Set BreakFast='"+breakFast+"',Lunch='"+lunch+"',Dinner='"+dinner+"' Where day='" + day + "';";
                DatabaseClass.SqlQuery(query);
                MessageBox.Show("Record of day '" + day + "' Updated!");
            }
        }

        // show Menu record on click
        private void btnMenu_Click(object sender, EventArgs e)
        {
            string showMenuQuery = "Select * FROM Menu;";
            DatabaseClass.Binding(dgvMenu, showMenuQuery, "Menu");
            string showMenuInOrderQuery = "Select * from menu Order by DayId;";
            DatabaseClass.Binding(dgvMenu, showMenuInOrderQuery, "Menu");
        }

        // Clear Fields on click
        private void btnMClear_Click(object sender, EventArgs e)
        {
            txtDay.Clear();
            txtMBreakFast.Clear();
            txtMDinner.Clear();
            txtMLunch.Clear();
        }

        //private void dgvMenu_CellContentClick(object sender, DataGridViewCellEventArgs e)
        //{

        //}

        private void dgvMenu_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            txtDay.Text = this.dgvMenu.CurrentRow.Cells[1].Value.ToString();
            txtMBreakFast.Text = this.dgvMenu.CurrentRow.Cells[2].Value.ToString();
            txtMLunch.Text = this.dgvMenu.CurrentRow.Cells[3].Value.ToString();
            txtMDinner.Text = this.dgvMenu.CurrentRow.Cells[4].Value.ToString();
        }

       
    }
}
