﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOP_Final_Project
{
    class ProductCategory
    {
        public int CatID { get; set; }
        public string CatName { get; set; }

        public static DataTable Display()
        {
            string sql = "Select * From tblCategory";
            DataTable dt = DB.getDatabyQuery(sql);
            return dt;
        }

    }
}
