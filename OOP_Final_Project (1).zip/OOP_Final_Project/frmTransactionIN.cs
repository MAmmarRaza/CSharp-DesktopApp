﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OOP_Final_Project
{
    public partial class frmTransactionIN : Form
    {
        public frmTransactionIN()
        {
            InitializeComponent();
            LoadSuppliers();
            LoadProductList();

        }

        void LoadProductList()
        {
            string sql = "Select ProductID,ProdName From tblProduct";
            DataTable dt = DB.getDatabyQuery(sql);
            cmbProdList.DataSource = dt;
            cmbProdList.DisplayMember = "ProdName";
            cmbProdList.ValueMember = "ProductID";


        }

        void LoadSuppliers()
        {
            string sql = "Select SID,Sname,SPhone From tblSupplier";
            DataTable dt = DB.getDatabyQuery(sql);
            cmbSupplier.DataSource = dt;
            cmbSupplier.DisplayMember = "Sname";
            cmbSupplier.ValueMember = "SID";

        }

        void LoadProduct(int ID)
        {
            string sql = $"Select ProductID,ProdName,ProdDesc,ProdPrice,CatID,ProdUnit From tblProduct where productid={ID} ";
            DataTable dt = DB.getDatabyQuery(sql);
            txtUnit.Text = dt.Rows[0]["ProdUnit"].ToString();
            txtUprice.Text = dt.Rows[0]["prodPrice"].ToString();

        }

        private void label11_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        void LoadSup(int id)
        {
            string sql = @"Select SID,Sname,SPhone From tblSupplier";
            DataTable dt = DB.getDatabyQuery(sql);
            txtSphone.Text = dt.Rows[0]["SPhone"].ToString();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                string sql = $"INSERT INTO tblSupplier(Sname,SPhone) values ('{txtSname.Text}','{txtSphone.Text}')";
                DB.SaveData(sql);
                MessageBox.Show("Data Saved to Database");
                LoadSuppliers();
                cmbSupplier.Refresh();

            }
            catch (Exception)
            {
                MessageBox.Show("Data Not Saved to Database Enter Data and Then Save");

            }

        }

        private void cmbSupplier_Leave(object sender, EventArgs e)
        {
            if (cmbSupplier.SelectedIndex > 0)
            {
                txtSid.Text = cmbSupplier.SelectedValue.ToString();
                txtSname.Text = cmbSupplier.Text;
                LoadSup(int.Parse(txtSid.Text));
            }
            else
            {
                txtSid.Text = "SUPPLIER ID";
                txtSname.Text = "SUPPLIER NAME";
                txtSphone.Text = "SUPPLIER PHONE NO.";
            }
        }

        float calPrice()
        {
            float price;
            int qty = int.Parse(txtQTY.Text.ToString());
            float uprice = float.Parse(txtUprice.Text);
            price = qty * uprice;
            return price;

        }
        DataTable dt = new DataTable();

        void calTotal()
        {
            float sum = 0;
            if (dgvOrder.Rows.Count > 0)
            {
                foreach (DataGridViewRow R in dgvOrder.Rows)
                {
                    sum += float.Parse(R.Cells["TotalPrice"].Value.ToString());
                }

            }
            txtGtotal.Text = sum.ToString();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            dgvOrder.Rows.Add(dgvOrder.Rows.Count + 1, cmbProdList.SelectedValue.ToString(), cmbSupplier.SelectedValue.ToString(), cmbProdList.Text, txtUprice.Text, txtUnit.Text, txtQTY.Text, calPrice());
            dgvOrder.Refresh();
            calTotal();
        }

        private void cmbProdList_Leave(object sender, EventArgs e)
        {
            if (cmbProdList.SelectedIndex >= 0)
            {
                LoadProduct(int.Parse(cmbProdList.SelectedValue.ToString()));
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtSid.Text) || dgvOrder.Rows.Count < 1)
            {
                MessageBox.Show(this, "Please select Supplier first, or no items are added.");
                return;
            }

            string sqli = $@"INSERT INTO [dbo].[tblSReciept]([SID],[TotalPrice],[EnterdBy])
                             VALUES({txtSid.Text},{txtGtotal.Text},'{GlobalVariables.loggedInuser.Uname}')
                             ; select SCOPE_IDENTITY() as billid";
            DataTable dt = DB.getDatabyQuery(sqli);
            if (dt.Rows.Count > 0)
            {

                int nBillId = int.Parse(dt.Rows[0]["billid"].ToString());


                foreach (DataGridViewRow row in dgvOrder.Rows)
                {

                    int pid = int.Parse(row.Cells["ProductID"].Value.ToString());
                    float price = float.Parse(row.Cells["UnitPrice"].Value.ToString());
                    float tPrice = float.Parse(row.Cells["TotalPrice"].Value.ToString());
                    string sqlord = $@"INSERT INTO [dbo].[tblSRecieptDetail]([BillID],[ProductID],[ProductName],[UnitPrice],[Unit],[TotalPrice])
                                       VALUES({nBillId},{pid},'{row.Cells["ProductName"].Value.ToString()}',{price},'{row.Cells["ProductUnit"].Value.ToString()}',{tPrice})";
                    DB.getDatabyQuery(sqlord);
                    MessageBox.Show("Bill Created");
                   
                }
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            frmHome frm = new frmHome();
            this.Hide();
            frm.Show();
        }
    }
}
