﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OOP_Final_Project
{
    public partial class frmManageCategory : Form
    {
        public frmManageCategory()
        {
            InitializeComponent();
            dgvCategory.DataSource = ProductCategory.Display();
        }

        void ClearTB()
        {
            
            txtCatName.Text = "CATEGORY NAME";
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            ProductCategory Cat = new ProductCategory();
            //Cat.CatID = int.Parse(txtCatID.Text);
            Cat.CatName = txtCatName.Text;
           
            try
            {
                string sql = $"INSERT INTO tblCategory(CatName) Values ('{Cat.CatName}')";
                DB.SaveData(sql);
                MessageBox.Show("Data Saved To Database");
                btnShow_Click(sender, e);
                ClearTB();
            }
            catch (Exception)
            {
                MessageBox.Show("Data Not Saved to Database");

            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            ProductCategory Cat = new ProductCategory();
            Cat.CatID = int.Parse(txtCatID.Text);
            Cat.CatName = txtCatName.Text;


            try
            {
                string sql = $@"UPDATE tblCategory(CatName)
                             SET 
                                 [CatName] = '{Cat.CatName}'
                                  where [CatID] = { Cat.CatID}
                             ";
                DB.SaveData(sql);
                MessageBox.Show("Data Updated in Database");
                btnShow_Click(sender, e);
                ClearTB();

            }
            catch (Exception)
            {
                MessageBox.Show("Data Not Updated");
                throw;

            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            ProductCategory Cat = new ProductCategory();
            Cat.CatID = int.Parse(txtCatID.Text);
            Cat.CatName = txtCatName.Text;

            try
            {
                string sql = $@"Delete tblCategory
                             where [CatID] = '{Cat.CatID}'
                             ";
                DB.SaveData(sql);
                MessageBox.Show("Data Deleted From Database");
                btnShow_Click(sender, e);
                ClearTB();

            }
            catch (Exception)
            {
                MessageBox.Show("Data Not Deleted");
                throw;

            }
        }

        private void btnShow_Click(object sender, EventArgs e)
        {
            dgvCategory.DataSource = ProductCategory.Display();
        }

        private void label3_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void dgvCategory_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dgvCategory_CellMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (dgvCategory.SelectedRows.Count > 0)
            {
                txtCatID.Text = dgvCategory.SelectedRows[0].Cells[0].Value.ToString();
                txtCatName.Text = dgvCategory.SelectedRows[0].Cells[1].Value.ToString();
            }
        }

        private void txtCatID_OnValueChanged(object sender, EventArgs e)
        {

        }

        private void frmManageCategory_Load(object sender, EventArgs e)
        {

        }

        private void btnHome_Click(object sender, EventArgs e)
        {
            frmHome frm = new frmHome();
            this.Hide();
            frm.Show();
        }
    }
}
