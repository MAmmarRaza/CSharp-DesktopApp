﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OOP_Final_Project
{
    class DB
    {
        public static string strConnection = @"Data Source=DESKTOP-SF2D9V5\EXPRESSSERVER;Initial Catalog=FinalProject;Integrated Security=True";
        public static SqlConnection connection = new SqlConnection(strConnection);
        public static SqlConnection CheckDBConnection()
        {
            try
            {
                connection.Open();
                connection.Close();
                MessageBox.Show("Connection is OK.....");

            }
            catch (Exception)
            {
                MessageBox.Show("Error Occured in Database Conenction");
                throw;
            }
            return connection;
        }

        public static DataTable getDatabyQuery(string sql)
        {

            SqlCommand cmd = new SqlCommand();
            cmd.Connection = connection;
            cmd.CommandType = System.Data.CommandType.Text;
            cmd.CommandText = sql;
            try
            {
                connection.Open();
                SqlDataAdapter dp = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                dp.Fill(dt);
                return dt;


            }
            catch (Exception)
            {
                MessageBox.Show("Error in Connection");
                throw;
            }
            finally
            {
                connection.Close();
            }

        }

        public static int SaveData(string sql)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = connection;
            cmd.CommandType = System.Data.CommandType.Text;
            cmd.CommandText = sql;
            try
            {
                connection.Open();
                return cmd.ExecuteNonQuery();
            }
            catch (Exception)
            {
                MessageBox.Show("Error in Connection");
                throw;
            }
            finally
            {
                connection.Close();
            }

        }

       

        public static User AuthenticateUser(string uName, string uPassword)
        {
            string sql = $@"SELECT Uname,Upassword,Role,UfullName From tblUser Where Uname = '{uName}' AND Upassword = '{uPassword}'";

            DataTable dt = DB.getDatabyQuery(sql);
            User retUser = new User();
            if (dt == null || dt.Rows.Count == 0)
            {
                return retUser;
            }
            else
            {

                retUser.Uname = uName;
                retUser.UPassword = uPassword;
                retUser.Role = dt.Rows[0]["Role"].ToString();
                retUser.UfullName = dt.Rows[0]["UfullName"].ToString();
               
                return retUser;
            }

        }



    }
}
