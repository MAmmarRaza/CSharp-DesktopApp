﻿namespace OOP_Final_Project
{
    partial class frmHome
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmHome));
            this.label1 = new System.Windows.Forms.Label();
            this.button6 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.label11 = new System.Windows.Forms.Label();
            this.btnLogOut = new System.Windows.Forms.Button();
            this.lblRole = new System.Windows.Forms.Label();
            this.lblCustomer = new System.Windows.Forms.LinkLabel();
            this.lblProduct = new System.Windows.Forms.LinkLabel();
            this.lblOut = new System.Windows.Forms.LinkLabel();
            this.lblSupplier = new System.Windows.Forms.LinkLabel();
            this.lblIN = new System.Windows.Forms.LinkLabel();
            this.lblCategory = new System.Windows.Forms.LinkLabel();
            this.lblUser = new System.Windows.Forms.LinkLabel();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI Black", 18F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.SteelBlue;
            this.label1.Location = new System.Drawing.Point(232, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(451, 32);
            this.label1.TabIndex = 0;
            this.label1.Text = "INVENTORY MANAGEMENT SYSTEM";
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(408, 597);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(85, 34);
            this.button6.TabIndex = 1;
            this.button6.Text = "button1";
            this.button6.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(153, 712);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(85, 34);
            this.button2.TabIndex = 1;
            this.button2.Text = "button1";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(94, 861);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(85, 34);
            this.button4.TabIndex = 1;
            this.button4.Text = "button1";
            this.button4.UseVisualStyleBackColor = true;
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(352, 966);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(85, 34);
            this.button8.TabIndex = 1;
            this.button8.Text = "button1";
            this.button8.UseVisualStyleBackColor = true;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label11.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.White;
            this.label11.Location = new System.Drawing.Point(821, 69);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(24, 25);
            this.label11.TabIndex = 19;
            this.label11.Text = "X";
            this.label11.Click += new System.EventHandler(this.label11_Click);
            // 
            // btnLogOut
            // 
            this.btnLogOut.Font = new System.Drawing.Font("Segoe UI Semibold", 11.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLogOut.Location = new System.Drawing.Point(744, 461);
            this.btnLogOut.Name = "btnLogOut";
            this.btnLogOut.Size = new System.Drawing.Size(89, 38);
            this.btnLogOut.TabIndex = 20;
            this.btnLogOut.Text = "LOG OUT";
            this.btnLogOut.UseVisualStyleBackColor = true;
            this.btnLogOut.Click += new System.EventHandler(this.btnLogOut_Click);
            // 
            // lblRole
            // 
            this.lblRole.AutoSize = true;
            this.lblRole.BackColor = System.Drawing.Color.Transparent;
            this.lblRole.Font = new System.Drawing.Font("Segoe UI Semibold", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRole.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblRole.Location = new System.Drawing.Point(56, 65);
            this.lblRole.Name = "lblRole";
            this.lblRole.Size = new System.Drawing.Size(104, 30);
            this.lblRole.TabIndex = 21;
            this.lblRole.Text = "User Role";
            this.lblRole.Click += new System.EventHandler(this.lblRole_Click);
            // 
            // lblCustomer
            // 
            this.lblCustomer.ActiveLinkColor = System.Drawing.Color.Black;
            this.lblCustomer.AutoSize = true;
            this.lblCustomer.BackColor = System.Drawing.Color.Transparent;
            this.lblCustomer.Font = new System.Drawing.Font("Segoe UI Black", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCustomer.LinkColor = System.Drawing.Color.Transparent;
            this.lblCustomer.Location = new System.Drawing.Point(388, 104);
            this.lblCustomer.Name = "lblCustomer";
            this.lblCustomer.Size = new System.Drawing.Size(129, 30);
            this.lblCustomer.TabIndex = 22;
            this.lblCustomer.TabStop = true;
            this.lblCustomer.Text = "CUSTOMER";
            this.lblCustomer.VisitedLinkColor = System.Drawing.Color.Black;
            this.lblCustomer.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lblCustomer_LinkClicked);
            // 
            // lblProduct
            // 
            this.lblProduct.ActiveLinkColor = System.Drawing.Color.Black;
            this.lblProduct.AutoSize = true;
            this.lblProduct.BackColor = System.Drawing.Color.Transparent;
            this.lblProduct.Font = new System.Drawing.Font("Segoe UI Black", 18F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProduct.ForeColor = System.Drawing.Color.White;
            this.lblProduct.LinkColor = System.Drawing.Color.White;
            this.lblProduct.Location = new System.Drawing.Point(583, 173);
            this.lblProduct.Name = "lblProduct";
            this.lblProduct.Size = new System.Drawing.Size(146, 32);
            this.lblProduct.TabIndex = 22;
            this.lblProduct.TabStop = true;
            this.lblProduct.Text = "PRODUCTS";
            this.lblProduct.VisitedLinkColor = System.Drawing.Color.Black;
            this.lblProduct.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lblProduct_LinkClicked);
            // 
            // lblOut
            // 
            this.lblOut.ActiveLinkColor = System.Drawing.Color.Black;
            this.lblOut.AutoSize = true;
            this.lblOut.BackColor = System.Drawing.Color.Transparent;
            this.lblOut.Font = new System.Drawing.Font("Segoe UI Black", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOut.LinkColor = System.Drawing.Color.White;
            this.lblOut.Location = new System.Drawing.Point(169, 157);
            this.lblOut.Name = "lblOut";
            this.lblOut.Size = new System.Drawing.Size(200, 25);
            this.lblOut.TabIndex = 22;
            this.lblOut.TabStop = true;
            this.lblOut.Text = "TRANSACTION OUT";
            this.lblOut.VisitedLinkColor = System.Drawing.Color.Black;
            this.lblOut.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lblOut_LinkClicked);
            // 
            // lblSupplier
            // 
            this.lblSupplier.ActiveLinkColor = System.Drawing.Color.Black;
            this.lblSupplier.AutoSize = true;
            this.lblSupplier.BackColor = System.Drawing.Color.Transparent;
            this.lblSupplier.Font = new System.Drawing.Font("Segoe UI Black", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSupplier.LinkColor = System.Drawing.Color.White;
            this.lblSupplier.Location = new System.Drawing.Point(110, 252);
            this.lblSupplier.Name = "lblSupplier";
            this.lblSupplier.Size = new System.Drawing.Size(124, 30);
            this.lblSupplier.TabIndex = 22;
            this.lblSupplier.TabStop = true;
            this.lblSupplier.Text = "SUPPLIERS";
            this.lblSupplier.VisitedLinkColor = System.Drawing.Color.Black;
            this.lblSupplier.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lblSupplier_LinkClicked);
            // 
            // lblIN
            // 
            this.lblIN.ActiveLinkColor = System.Drawing.Color.Black;
            this.lblIN.AutoSize = true;
            this.lblIN.BackColor = System.Drawing.Color.Transparent;
            this.lblIN.Font = new System.Drawing.Font("Segoe UI Black", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIN.LinkColor = System.Drawing.Color.White;
            this.lblIN.Location = new System.Drawing.Point(87, 432);
            this.lblIN.Name = "lblIN";
            this.lblIN.Size = new System.Drawing.Size(182, 25);
            this.lblIN.TabIndex = 22;
            this.lblIN.TabStop = true;
            this.lblIN.Text = "TRANSACTION IN";
            this.lblIN.VisitedLinkColor = System.Drawing.Color.Black;
            // 
            // lblCategory
            // 
            this.lblCategory.ActiveLinkColor = System.Drawing.Color.Black;
            this.lblCategory.AutoSize = true;
            this.lblCategory.BackColor = System.Drawing.Color.Transparent;
            this.lblCategory.Font = new System.Drawing.Font("Segoe UI Black", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCategory.LinkColor = System.Drawing.Color.White;
            this.lblCategory.Location = new System.Drawing.Point(681, 427);
            this.lblCategory.Name = "lblCategory";
            this.lblCategory.Size = new System.Drawing.Size(142, 30);
            this.lblCategory.TabIndex = 22;
            this.lblCategory.TabStop = true;
            this.lblCategory.Text = "CATEGORIES";
            this.lblCategory.VisitedLinkColor = System.Drawing.Color.Black;
            this.lblCategory.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lblCategory_LinkClicked);
            // 
            // lblUser
            // 
            this.lblUser.ActiveLinkColor = System.Drawing.Color.Black;
            this.lblUser.AutoSize = true;
            this.lblUser.BackColor = System.Drawing.Color.Transparent;
            this.lblUser.Font = new System.Drawing.Font("Segoe UI Black", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUser.LinkColor = System.Drawing.Color.White;
            this.lblUser.Location = new System.Drawing.Point(681, 275);
            this.lblUser.Name = "lblUser";
            this.lblUser.Size = new System.Drawing.Size(66, 30);
            this.lblUser.TabIndex = 22;
            this.lblUser.TabStop = true;
            this.lblUser.Text = "USER";
            this.lblUser.VisitedLinkColor = System.Drawing.Color.Black;
            this.lblUser.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lblUser_LinkClicked);
            // 
            // frmHome
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.ClientSize = new System.Drawing.Size(898, 568);
            this.Controls.Add(this.lblSupplier);
            this.Controls.Add(this.lblCategory);
            this.Controls.Add(this.lblUser);
            this.Controls.Add(this.lblProduct);
            this.Controls.Add(this.lblIN);
            this.Controls.Add(this.lblOut);
            this.Controls.Add(this.lblCustomer);
            this.Controls.Add(this.lblRole);
            this.Controls.Add(this.btnLogOut);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.button8);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "frmHome";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frmHome";
            this.Load += new System.EventHandler(this.frmHome_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button btnLogOut;
        private System.Windows.Forms.Label lblRole;
        private System.Windows.Forms.LinkLabel lblCustomer;
        private System.Windows.Forms.LinkLabel lblProduct;
        private System.Windows.Forms.LinkLabel lblOut;
        private System.Windows.Forms.LinkLabel lblSupplier;
        private System.Windows.Forms.LinkLabel lblIN;
        private System.Windows.Forms.LinkLabel lblCategory;
        private System.Windows.Forms.LinkLabel lblUser;
    }
}