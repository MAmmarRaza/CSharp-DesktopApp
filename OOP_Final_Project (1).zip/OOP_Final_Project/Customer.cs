﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOP_Final_Project
{
    class Customer
    {
        public int CustID { get; set; }
        public string CustName { get; set; }
        public string CustPhone { get; set; }

        public static DataTable Display()
        {
            string sql = "Select * From tblCustomer";
            DataTable dt = DB.getDatabyQuery(sql);
            return dt;
        }

    }
}
